execute as @a unless score @s temp_death = @s Death run effect give @s minecraft:saturation infinite 255 true
execute as @a run scoreboard players operation @s temp_death = @s Death